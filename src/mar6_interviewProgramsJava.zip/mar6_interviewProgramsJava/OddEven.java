package mar6_interviewProgramsJava;

public class OddEven {

	public static void main(String[] args) {
		int num = 11;
		
		if(num % 2 == 0 ){
			System.out.println("Even");
		} else {
			System.out.println("Odd");
		}

	}
}
